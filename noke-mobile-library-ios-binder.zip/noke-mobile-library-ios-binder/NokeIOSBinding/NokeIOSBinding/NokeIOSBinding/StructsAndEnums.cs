﻿using System.Runtime.InteropServices;
using ObjCRuntime;

namespace NokeMobileLibrary
{
    static class CFunctions
    {
        // extern void aes_enc_dec (unsigned char *state, unsigned char *key, unsigned char dir);
        [DllImport("__Internal")]
        static extern unsafe void aes_enc_dec(byte* state, byte* key, byte dir);
    }

    [Native]
    public enum NokeDeviceConnectionState : long
    {
        Disconnected = 0,
        Discovered = 1,
        Connecting = 2,
        Connected = 3,
        Syncing = 4,
        Unlocked = 5,
        Error = 6
    }

    [Native]
    public enum NokeDeviceLockState : long
    {
      
        Unknown = -1,
        Unlocked = 0,
        Unshackled = 2,
        Locked = 3,
        Unshackling = 4,
        Unlocking = 5,
        LockedNoMagnet = 7
    }

    [Native]
    public enum NokeDeviceManagerError : long
    {
        APIErrorInternalServer = 1,
        APIErrorAPIKey = 2,
        APIErrorInput = 3,
        APIErrorRequestMethod = 4,
        APIErrorInvalidEndpoint = 5,
        APIErrorCompanyNotFound = 6,
        APIErrorLockNotFound = 7,
        APIErrorUnknown = 99,
        GoUnlockError = 100,
        GoUploadError = 101,
        DeviceSuccessResult = 260,
        DeviceErrorInvalidKey = 261,
        DeviceErrorInvalidCmd = 262,
        DeviceErrorInvalidPermission = 263,
        DeviceShutdownResult = 264,
        DeviceErrorInvalidData = 265,
        DeviceBatteryDataResult = 266,
        DeviceErrorInvalidResult = 267,
        DeviceErrorUnknown = 268,
        LibraryErrorInvalidOfflineKey = 301,
        LibraryErrorNoModeSet = 302,
        LibraryConnectionTimeout = 317
    }

    [Native]
    public enum NokeLibraryMode : long
    {
        Sandbox = 0,
        Production = 1,
        Develop = 2,
        Open = 3,
        Custom = 4
    }

    [Native]
    public enum NokeManagerBluetoothState : long
    {
        Unknown = 0,
        Resetting = 1,
        Unsupported = 2,
        Unauthorized = 3,
        PoweredOff = 4,
        PoweredOn = 5
    }
}
