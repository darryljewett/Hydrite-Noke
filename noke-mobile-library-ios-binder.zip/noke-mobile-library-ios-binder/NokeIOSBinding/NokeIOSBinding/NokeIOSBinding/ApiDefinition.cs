﻿using System;
using CoreBluetooth;
using Foundation;
using NokeMobileLibrary;
using ObjCRuntime;

namespace NokeMobileLibrary
{
    [Static]
    partial interface Constants
    {
        // extern double NokeMobileLibraryVersionNumber;
        [Field("NokeMobileLibraryVersionNumber", "__Internal")]
        double NokeMobileLibraryVersionNumber { get; }
    }

    // @interface NokeDevice : NSObject <CBPeripheralDelegate, NSCoding>
    [BaseType(typeof(NSObject), Name = "_TtC17NokeMobileLibrary10NokeDevice")]
    [DisableDefaultCtor]
    interface NokeDevice : ICBPeripheralDelegate, INSCoding
    {
        // @property (copy, nonatomic) NSString * _Nonnull name;
        [Export("name")]
        string Name { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull mac;
        [Export("mac")]
        string Mac { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull serial;
        [Export("serial")]
        string Serial { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull uuid;
        [Export("uuid")]
        string Uuid { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull version;
        [Export("version")]
        string Version { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull trackingKey;
        [Export("trackingKey")]
        string TrackingKey { get; set; }

        // @property (copy, nonatomic) NSString * _Nullable session;
        [NullAllowed, Export("session")]
        string Session { get; set; }

        // @property (nonatomic) uint64_t battery;
        [Export("battery")]
        ulong Battery { get; set; }

        // @property (nonatomic, strong) NSNumber * _Nonnull RSSI;
        [Export("RSSI", ArgumentSemantic.Strong)]
        NSNumber RSSI { get; set; }

        // @property (nonatomic) enum NokeDeviceLockState lockState;
        [Export("lockState", ArgumentSemantic.Assign)]
        NokeDeviceLockState LockState { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull unlockCmd;
        [Export("unlockCmd")]
        string UnlockCmd { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull offlineKey;
        [Export("offlineKey")]
        string OfflineKey { get; set; }

        // -(void)encodeWithCoder:(NSCoder * _Nonnull)aCoder;
        [Export("encodeWithCoder:")]
        void EncodeWithCoder(NSCoder aCoder);

        // -(instancetype _Nullable)initWithCoder:(NSCoder * _Nonnull)aDecoder;
        [Export("initWithCoder:")]
        NativeHandle Constructor(NSCoder aDecoder);

        // -(void)setVersionWithData:(NSData * _Nonnull)data deviceName:(NSString * _Nonnull)deviceName;
        [Export("setVersionWithData:deviceName:")]
        void SetVersionWithData(NSData data, string deviceName);

        // -(NSString * _Nonnull)getHardwareVersion __attribute__((warn_unused_result("")));
        [Export("getHardwareVersion")]
        string HardwareVersion { get; }

        // -(NSString * _Nonnull)getSoftwareVersion __attribute__((warn_unused_result("")));
        [Export("getSoftwareVersion")]
        string SoftwareVersion { get; }

        // -(void)peripheral:(CBPeripheral * _Nonnull)peripheral didDiscoverServices:(NSError * _Nullable)error;
        [Export("peripheral:didDiscoverServices:")]
        void Peripheral(CBPeripheral peripheral, [NullAllowed] NSError error);

        // -(void)peripheral:(CBPeripheral * _Nonnull)peripheral didDiscoverCharacteristicsForService:(CBService * _Nonnull)service error:(NSError * _Nullable)error;
        [Export("peripheral:didDiscoverCharacteristicsForService:error:")]
        void Peripheral(CBPeripheral peripheral, CBService service, [NullAllowed] NSError error);

        // -(void)peripheral:(CBPeripheral * _Nonnull)peripheral didUpdateValueForCharacteristic:(CBCharacteristic * _Nonnull)characteristic error:(NSError * _Nullable)error;
        [Export("peripheral:didUpdateValueForCharacteristic:error:")]
        void Peripheral(CBPeripheral peripheral, CBCharacteristic characteristic, [NullAllowed] NSError error);

        // -(void)sendCommands:(NSString * _Nonnull)commands;
        [Export("sendCommands:")]
        void SendCommands(string commands);

        // -(void)setOfflineValuesWithKey:(NSString * _Nonnull)key command:(NSString * _Nonnull)command;
        [Export("setOfflineValuesWithKey:command:")]
        void SetOfflineValuesWithKey(string key, string command);

        // -(NSString * _Nonnull)offlineUnlockWithKey:(NSString * _Nonnull)key command:(NSString * _Nonnull)command addTimestamp:(BOOL)addTimestamp __attribute__((warn_unused_result("")));
        [Export("offlineUnlockWithKey:command:addTimestamp:")]
        string OfflineUnlockWithKey(string key, string command, bool addTimestamp);

        // -(NSString * _Nonnull)offlineUnlockWithAddTimestamp:(BOOL)addTimestamp __attribute__((warn_unused_result("")));
        [Export("offlineUnlockWithAddTimestamp:")]
        string OfflineUnlockWithAddTimestamp(bool addTimestamp);
    }

    // @interface NokeDeviceHandler : NSObject
    [BaseType(typeof(NSObject), Name = "_TtC17NokeMobileLibrary17NokeDeviceHandler")]
    interface NokeDeviceHandler
    {
        // -(NSString * _Nonnull)setLibraryModeWithMode:(NSString * _Nonnull)mode apiKey:(NSString * _Nonnull)apiKey __attribute__((warn_unused_result("")));
        [Export("setLibraryModeWithMode:apiKey:")]
        string SetLibraryModeWithMode(string mode, string apiKey);

        // -(void)requestUnlockWithNoke:(NokeDevice * _Nonnull)noke serverUrl:(NSString * _Nonnull)serverUrl email:(NSString * _Nonnull)email key:(NSString * _Nonnull)key command:(NSString * _Nonnull)command;
        [Export("requestUnlockWithNoke:serverUrl:email:key:command:")]
        void RequestUnlockWithNoke(NokeDevice noke, string serverUrl, string email, string key, string command);

        // -(void)requestOfflineUnlockWithNoke:(NokeDevice * _Nonnull)noke key:(NSString * _Nonnull)key command:(NSString * _Nonnull)command;
        [Export("requestOfflineUnlockWithNoke:key:command:")]
        void RequestOfflineUnlockWithNoke(NokeDevice noke, string key, string command);
    }

    // @interface NokeDeviceManager : NSObject <CBCentralManagerDelegate>
    [BaseType(typeof(NSObject), Name = "_TtC17NokeMobileLibrary17NokeDeviceManager")]
    [DisableDefaultCtor]
    interface NokeDeviceManager : ICBCentralManagerDelegate
    {
        [Wrap("WeakDelegate")]
        [NullAllowed]
        NokeDeviceManagerDelegate Delegate { get; set; }

        // @property (nonatomic, strong) id<NokeDeviceManagerDelegate> _Nullable delegate;
        [NullAllowed, Export("delegate", ArgumentSemantic.Strong)]
        NSObject WeakDelegate { get; set; }

        [Wrap("WeakUploadDelegate")]
        [NullAllowed]
        NokeUploadDelegate UploadDelegate { get; set; }

        // @property (nonatomic, strong) id<NokeUploadDelegate> _Nullable uploadDelegate;
        [NullAllowed, Export("uploadDelegate", ArgumentSemantic.Strong)]
        NSObject WeakUploadDelegate { get; set; }

        // +(NokeDeviceManager * _Nonnull)shared __attribute__((warn_unused_result("")));
        [Static]
        [Export("shared")]
        NokeDeviceManager Shared { get; }

        // -(void)startScanForNokeDevices;
        [Export("startScanForNokeDevices")]
        void StartScanForNokeDevices();

        // -(void)stopScan;
        [Export("stopScan")]
        void StopScan();

        // -(void)connectToNokeDevice:(NokeDevice * _Nonnull)noke;
        [Export("connectToNokeDevice:")]
        void ConnectToNokeDevice(NokeDevice noke);

        // -(void)disconnectNokeDevice:(NokeDevice * _Nonnull)noke;
        [Export("disconnectNokeDevice:")]
        void DisconnectNokeDevice(NokeDevice noke);

        // -(void)setAllowAllNokeDevices:(BOOL)allow;
        [Export("setAllowAllNokeDevices:")]
        void SetAllowAllNokeDevices(bool allow);

        // -(void)centralManagerDidUpdateState:(CBCentralManager * _Nonnull)central;
        [Export("centralManagerDidUpdateState:")]
        void CentralManagerDidUpdateState(CBCentralManager central);

        // -(void)UpdatedState:(CBCentralManager * _Nonnull)central;
        [Export("UpdatedState:")]
        void UpdatedState(CBCentralManager central);

        // -(void)centralManager:(CBCentralManager * _Nonnull)central didDiscoverPeripheral:(CBPeripheral * _Nonnull)peripheral advertisementData:(NSDictionary<NSString *,id> * _Nonnull)advertisementData RSSI:(NSNumber * _Nonnull)RSSI;
        [Export("centralManager:didDiscoverPeripheral:advertisementData:RSSI:")]
        void CentralManager(CBCentralManager central, CBPeripheral peripheral, NSDictionary<NSString, NSObject> advertisementData, NSNumber RSSI);

        // -(void)centralManager:(CBCentralManager * _Nonnull)central didConnectPeripheral:(CBPeripheral * _Nonnull)peripheral;
        [Export("centralManager:didConnectPeripheral:")]
        void CentralManager(CBCentralManager central, CBPeripheral peripheral);

        // -(void)centralManager:(CBCentralManager * _Nonnull)central didDisconnectPeripheral:(CBPeripheral * _Nonnull)peripheral error:(NSError * _Nullable)error;
        [Export("centralManager:didDisconnectPeripheral:error:")]
        void CentralManager(CBCentralManager central, CBPeripheral peripheral, [NullAllowed] NSError error);

        // -(void)addNoke:(NokeDevice * _Nonnull)noke;
        [Export("addNoke:")]
        void AddNoke(NokeDevice noke);

        // -(void)removeNokeWithNoke:(NokeDevice * _Nonnull)noke;
        [Export("removeNokeWithNoke:")]
        void RemoveNokeWithNoke(NokeDevice noke);

        // -(void)removeNokeWithMac:(NSString * _Nonnull)mac;
        [Export("removeNokeWithMac:")]
        void RemoveNokeWithMac(string mac);

        // -(void)removeAllNoke;
        [Export("removeAllNoke")]
        void RemoveAllNoke();

        // -(NSInteger)getNokeCount __attribute__((warn_unused_result("")));
        [Export("getNokeCount")]
        nint NokeCount { get; }

        // -(NSDictionary<NSString *,NokeDevice *> * _Nonnull)getAllNoke __attribute__((warn_unused_result("")));
        [Export("getAllNoke")]
        NSDictionary<NSString, NokeDevice> AllNoke { get; }

        // -(NokeDevice * _Nullable)nokeWithUUID:(NSString * _Nonnull)uuid __attribute__((warn_unused_result("")));
        [Export("nokeWithUUID:")]
        [return: NullAllowed]
        NokeDevice NokeWithUUID(string uuid);

        // -(NokeDevice * _Nullable)nokeWithMac:(NSString * _Nonnull)mac __attribute__((warn_unused_result("")));
        [Export("nokeWithMac:")]
        [return: NullAllowed]
        NokeDevice NokeWithMac(string mac);

        // -(NokeDevice * _Nullable)nokeWithPeripheral:(CBPeripheral * _Nonnull)peripheral __attribute__((warn_unused_result("")));
        [Export("nokeWithPeripheral:")]
        [return: NullAllowed]
        NokeDevice NokeWithPeripheral(CBPeripheral peripheral);

        // -(void)setAPIKey:(NSString * _Nonnull)apiKey;
        [Export("setAPIKey:")]
        void SetAPIKey(string apiKey);

        // -(void)setLibraryMode:(enum NokeLibraryMode)mode customURL:(NSString * _Nonnull)customURL;
        [Export("setLibraryMode:customURL:")]
        void SetLibraryMode(NokeLibraryMode mode, string customURL);

        // -(void)restoreKeyWithNoke:(NokeDevice * _Nonnull)noke;
        [Export("restoreKeyWithNoke:")]
        void RestoreKeyWithNoke(NokeDevice noke);

        // -(void)connectionTimeWasReached;
        [Export("connectionTimeWasReached")]
        void ConnectionTimeWasReached();
    }

    // @protocol NokeDeviceManagerDelegate
    [Protocol(Name = "_TtP17NokeMobileLibrary25NokeDeviceManagerDelegate_")]
    interface NokeDeviceManagerDelegate
    {
        // @required -(void)nokeDeviceDidUpdateStateTo:(enum NokeDeviceConnectionState)state noke:(NokeDevice * _Nonnull)noke;
        [Abstract]
        [Export("nokeDeviceDidUpdateStateTo:noke:")]
        void NokeDeviceDidUpdateStateTo(NokeDeviceConnectionState state, NokeDevice noke);

        // @required -(void)nokeDeviceDidShutdownWithNoke:(NokeDevice * _Nonnull)noke isLocked:(BOOL)isLocked didTimeout:(BOOL)didTimeout;
        [Abstract]
        [Export("nokeDeviceDidShutdownWithNoke:isLocked:didTimeout:")]
        void NokeDeviceDidShutdownWithNoke(NokeDevice noke, bool isLocked, bool didTimeout);

        // @required -(void)nokeErrorDidOccurWithError:(enum NokeDeviceManagerError)error message:(NSString * _Nonnull)message noke:(NokeDevice * _Nullable)noke;
        [Abstract]
        [Export("nokeErrorDidOccurWithError:message:noke:")]
        void NokeErrorDidOccurWithError(NokeDeviceManagerError error, string message, [NullAllowed] NokeDevice noke);

        // @required -(void)didUploadDataWithResult:(NSInteger)result message:(NSString * _Nonnull)message;
        [Abstract]
        [Export("didUploadDataWithResult:message:")]
        void DidUploadDataWithResult(nint result, string message);

        // @required -(void)bluetoothManagerDidUpdateStateWithState:(enum NokeManagerBluetoothState)state;
        [Abstract]
        [Export("bluetoothManagerDidUpdateStateWithState:")]
        void BluetoothManagerDidUpdateStateWithState(NokeManagerBluetoothState state);

        // @required -(void)nokeReadyForFirmwareUpdateWithNoke:(NokeDevice * _Nonnull)noke;
        [Abstract]
        [Export("nokeReadyForFirmwareUpdateWithNoke:")]
        void NokeReadyForFirmwareUpdateWithNoke(NokeDevice noke);
    }

    // @interface NokeLibraryApiClient : NSObject
    [BaseType(typeof(NSObject), Name = "_TtC17NokeMobileLibrary20NokeLibraryApiClient")]
    interface NokeLibraryApiClient
    {
    }

    // @protocol NokeUploadDelegate
    [Protocol(Name = "_TtP17NokeMobileLibrary18NokeUploadDelegate_")]
    interface NokeUploadDelegate
    {
        // @required -(void)didReceiveUploadDataWithData:(NSDictionary<NSString *,id> * _Nonnull)data;
        [Abstract]
        [Export("didReceiveUploadDataWithData:")]
        void DidReceiveUploadDataWithData(NSDictionary<NSString, NSObject> data);
    }
}
