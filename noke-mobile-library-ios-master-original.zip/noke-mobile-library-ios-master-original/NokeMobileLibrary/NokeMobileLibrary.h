#import <Foundation/Foundation.h>

//! Project version number for Once.
FOUNDATION_EXPORT double NokeMobileLibraryVersionNumber;

//! Project version string for Once.
FOUNDATION_EXPORT const unsigned char NokeMobileLibraryVersionString[];